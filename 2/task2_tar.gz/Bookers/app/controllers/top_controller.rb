class TopController < ApplicationController
   def index
   end
end
